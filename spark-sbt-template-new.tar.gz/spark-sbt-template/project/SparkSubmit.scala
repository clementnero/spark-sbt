import sbt._
import Keys._
import sbtsparksubmit.SparkSubmitPlugin.autoImport._
import sbtassembly.AssemblyKeys._
import Attributed._

object SparkSubmit {
  lazy val settings =
    SparkSubmitSetting(
      SparkSubmitSetting("sparkHelp",
        Seq(
          "--help"
        )
      ),
      {
        val task = SparkSubmitSetting("sparkLocal")
        task.settings(sparkSubmitSparkArgs in task := {
          Seq(
            "--master", "local"
          )},
	  sparkSubmitJar in task := assembly.value.getAbsolutePath
	)
	task
      },
      {
        val task = SparkSubmitSetting("sparkYarn")
        task.settings(sparkSubmitSparkArgs in task := {
          Seq(
            "--master", "yarn"
          )},
	  sparkSubmitJar in task := assembly.value.getAbsolutePath,
	  sparkSubmitPropertiesFile := Some(s"${(Keys.resourceDirectory in Compile).value}/conf/spark-yarn-defaults.conf"),
	  sparkSubmitClasspath := {
  		new File(sys.env.getOrElse("HADOOP_CONF_DIR", "")) +:
    		data((fullClasspath in Compile).value)
	 })
	task
      }
    )
}

