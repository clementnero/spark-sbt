package com.atos.fastconnect

import org.apache.spark.{SparkConf, SparkContext}
import scala.util.Random


object BatchJob {

  def main(args: Array[String]) {

    if (args.length < 2) {
      System.err.println(
        s"""
           |Usage: BatchJob <size> <max>
           |  <size> size of the sequence
           |  <max> the max of the random modulo to apply before count
        """.stripMargin)
      System.exit(1)
    }


    // get parameter
    val Array(size,max) = args

    // init contexts
    val sparkConf = new SparkConf().setAppName("BatchJob")
    val sc = new SparkContext(sparkConf)
    //val sqlContext = new SQLContext(sc)

    // gives access to all the SQL functions and implicit conversions.
    //import sqlContext.implicits._

    val rdd =
      sc.parallelize(1 to size.toInt,10)
        .map(x => (x % (Random.nextInt(max.toInt)+1),1))
        .reduceByKey(_ + _)
        .sortBy(_._2,false)

    rdd.collect.foreach(println)

    sc.stop()

  }
}
