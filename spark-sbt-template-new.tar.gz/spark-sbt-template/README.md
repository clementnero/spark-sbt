# spark-sbt-template

sbt build project

 batch
 streaming.
 
+ Projects' dependencies are nicely handled for generating 'ligtht' fat jars by assembling the essential libraries. 
+ Includes 'Runner' projects for 'in Intellij' executions (cf. Run -> Edit Configurations).
+ [TO FIX] Configuration of modules may need to be updated in order to set the scala-library dependency to "provided" (transitive dependencies)

