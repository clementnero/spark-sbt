package com.atos.fastconnect

import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.{Seconds, StreamingContext}

import scala.collection.mutable.Queue
import scala.util.Random


object StreamingJob {

  def main(args: Array[String]) {

    if (args.length < 2) {
      System.err.println(
        s"""
           |Usage: StreamingJob <size> <max>
           |  <size> size of the sequence
           |  <max> the max of the random modulo to apply before count
        """.stripMargin)
      System.exit(1)
    }

    // get parameter
    val Array(size,max) = args

    // Create the context
    val sparkConf = new SparkConf().setAppName("StreamingJob")
    val ssc = new StreamingContext(sparkConf, Seconds(1))


    // Create the queue through which RDDs can be pushed to a QueueInputDStream
    val rddQueue = new Queue[RDD[Int]]()

    // Create the QueueInputDStream and use it do some processing
    // Each RDD pushed into the queue will be treated as a batch of data in the DStream, and processed like a stream
    // A useless complex processing
    ssc.queueStream(rddQueue)
      .transform(
        _.mapPartitionsWithIndex{
          (index,partition) =>
            val rand = new Random(index+System.currentTimeMillis)
            partition.map{
              x => (x % (rand.nextInt(max.toInt) + 1),1)}
        })
      .reduceByKey(_ + _)
      .transform(_.sortBy(_._2,false))
      .print()

    ssc.start()

    // Create and push some RDDs into
    for (i <- 1 to 10) {
      rddQueue.synchronized {
        rddQueue += ssc.sparkContext.parallelize(1 to size.toInt, 10)
      }
      Thread.sleep(1000)
    }

    // Stop the streaming
    ssc.stop()

  }
}
